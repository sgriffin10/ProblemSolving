def first_criteria(word):
    ''' calculates words that have two letter sequence that repeats '''
    for letter in word:
        for i in range(len(word) - 3):
            combo_check = word[i: i + 2]
            if combo_check in word[i + 2:]:
                return True
    return False

# print(first_criteria('xwhqribrnelqbrrm'))
# print(first_criteria('merpprep'))
# print(first_criteria('rbnebnznhkvfvcaj'))

def second_criteria(word):
    ''' calculates words that have xyx-type strings '''
    for letter in word:
        for i in range(len(word) - 2):
            if word[i] == word[i + 2]:
                return True
        return False

# print(second_criteria('sjotvezauipapxcj'))
# print(second_criteria('merpprep'))
# print(second_criteria('qpnhylbxbhbyftkx'))

def find_awesome_words():
    """
    returns the number of awesome words in the text file
    """
    f = open('drunkard_words.txt')
    num_of_awesome_words = 0 
    for line in f:
        word = line.strip()
        for word in f:
            if first_criteria(word) and second_criteria(word):
                    print(word)
                    num_of_awesome_words += 1
    return num_of_awesome_words

# print(find_awesome_words())
