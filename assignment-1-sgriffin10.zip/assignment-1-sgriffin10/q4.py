def avoids(word):
    ''' calculates words that avoid 'ab' 'cd' and 'xy '''
    first_letter = 0
    second_letter = 2
    for letter in word:
        if word[first_letter:second_letter].lower() == 'ab' or word[first_letter:second_letter].lower() == 'cd' or word[first_letter:second_letter].lower() == 'xy':
            return False
        else:
            first_letter += 1
            second_letter += 1
    return True

# print(avoids('tsfbsha'))
# print(avoids('tsfashb'))
# print(avoids('tsfshab'))

def repeat_letters(word):
    ''' calculates words that have repeat letter '''
    letter = 0
    while letter < len(word)-1:
        if word[letter] == word[letter+1]:
            return True
        else:
            letter += 1
    return False

# print(repeat_letters('yessir'))
# print(repeat_letters('helo'))

def contains_vowels(word):
    ''' calculates words that contain 3 or more vowels '''
    counter = 0
    for letter in word:
        if letter in 'aeiou':
            counter += 1
            if counter == 3:
                return True
    return False

# print(contains_vowels('absolutely'))
# print(contains_vowels('hello'))
# print(contains_vowels('nyc'))

def find_good_words():
    """
    return the number of good words in the text file: 
    contain at least three vowels (aeiou only).
    contain at least one letter that occurs twice in a row.
    not contain any of the disallowed strings even if they are part of above requirements. 
    The disallowed strings are ab, cd and xy
    """
    f = open('drunkard_words.txt')
    num_of_good_words = 0 
    for line in f:
        word = line.strip()
        print(word)
        if avoids(word) and repeat_letters(word) and contains_vowels(word):
            num_of_good_words += 1
            print(word)
    return num_of_good_words

# print(find_good_words())

