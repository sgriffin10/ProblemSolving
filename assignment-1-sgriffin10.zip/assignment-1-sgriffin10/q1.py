def factors(n):
	"""Return a list of the prime factors for a number."""
	a = []               
	f = 2  #first prime factor              
	while n > 1:         
		if n % f == 0:       
			a.append(f)         
			n /= f              
		else:                
			f += 1              
	return a         

num = input("Please enter an integer: ") #asks for inpit
try:
    print(factors(int(num)))
except ValueError: #if do not enter an integer, requests that you re-enter input
    new_num = input("That is not an integer, please re-enter a numeric integer: ")
    print(factors(int(new_num)))



