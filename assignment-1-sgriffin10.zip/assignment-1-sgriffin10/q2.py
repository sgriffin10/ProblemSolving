import random
x = 0
y = 0

def drunkard_walk(x, y, n):
    """
    x, y: the original location
    n: the number of intersections(steps)
    return the Manhattan distance after n intersections(steps) from the origin
    """
    distance = 0
    directions = ['N','S','E','W'] 
    for i in range(1, n+1): 
        a = random.choice(directions)
        if a == 'N':
            y += 1
            print('Current position is: ({},{})'.format(x,y))
        elif a == 'S':
            y -= 1
            print('Current position is: ({},{})'.format(x,y))
        elif a == 'E':
            x += 1
            print('Current position is: ({},{})'.format(x,y))
        else:
            x -= 1
            print('Current position is: ({},{})'.format(x,y))
    distance = abs(x) + abs(y) 
    return (distance)

n = int(input("Type in number of steps: "))
print(f"The drunkard started from ({x},{y}).")
distance = drunkard_walk(x, y, n)
print(f"After {n} intersections, he's {distance} blocks from where he started.")
