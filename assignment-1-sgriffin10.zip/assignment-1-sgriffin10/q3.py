'''
draw the drunkard's walk
'''
import random
x = 0
y = 0


def drunkard_walk(x, y, n):
    """
    x, y: the original location
    n: the number of intersections(steps)
    return the Manhattan distance after n intersections(steps) from the origin
    """
    distance = 0
    directions = ['N','S','E','W']
    for i in range(1, n+1):
        a = random.choice(directions)
        t.fd(30)
        t.lt(20)
        t.color("turquoise", 'blue')
        if a == 'N':
            y += 1
            print('Current position is: ({},{})'.format(x,y))
            t.setheading(90)
        elif a == 'S':
            y -= 1
            print('Current position is: ({},{})'.format(x,y))
            t.setheading(270)
        elif a == 'E':
            x += 1
            print('Current position is: ({},{})'.format(x,y))
            t.setheading(0)
        else:
            x -= 1
            print('Current position is: ({},{})'.format(x,y))
            t.setheading(180)
    distance = abs(x) + abs(y)
    return (distance)

import turtle
import math
t = turtle.Turtle()
print(t)
n = int(input("Type in number of steps: "))
print(f"The drunkard started from ({x},{y}).")
distance = drunkard_walk(x, y, n)
print(f"After {n} intersections, he or she is {distance} blocks from where he started.")
# turtle.bye()
turtle.mainloop()



